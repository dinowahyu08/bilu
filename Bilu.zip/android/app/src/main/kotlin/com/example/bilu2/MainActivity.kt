package com.example.bilu2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
