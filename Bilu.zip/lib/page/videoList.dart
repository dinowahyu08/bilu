import 'package:bilu2/page/videoPage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Import this for rootBundle
import 'dart:convert';

class VideoListScreen extends StatefulWidget {
  @override
  _VideoListScreenState createState() => _VideoListScreenState();
}

class _VideoListScreenState extends State<VideoListScreen> {
  List<dynamic> _videos = [];

  @override
  void initState() {
    super.initState();
    fetchVideos(); // Memanggil fungsi untuk mengambil data video
  }

  Future<void> fetchVideos() async {
    try {
      // Load JSON from assets
      final String response = await rootBundle.loadString('assets/videos.json');
      final data = json.decode(response);
      setState(() {
        _videos = data['videos']; // Menyimpan data video ke dalam state
      });
    } catch (e) {
      print("Error fetching videos: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Video List')),
      body: ListView.builder(
        itemCount: _videos.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(_videos[index]['title']),
            subtitle: Text(_videos[index]['description']),
            onTap: () {
              // Navigasi ke VideoPlayerScreen
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => VideoPlayerScreen(
                    title: _videos[index]['title'],
                    videoUrl: _videos[index]['url'],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
