import 'package:bilu2/page/absensi.dart';
import 'package:bilu2/page/videoList.dart';
import 'package:bilu2/theme.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeClient extends StatefulWidget {
  const HomeClient({super.key});

  @override
  State<HomeClient> createState() => _HomeClientState();
}

class _HomeClientState extends State<HomeClient> {
  String _username = '';

  @override
  void initState() {
    super.initState();
    _loadUserData(); // Memuat data pengguna dari SharedPreferences
  }

  // Fungsi untuk mengambil data nama pengguna dari SharedPreferences
  Future<void> _loadUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _username = prefs.getString('loggedInUser') ?? ''; // Ambil nama pengguna
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 45,
                ),
                Text(
                  'Halo $_username',
                  style: boldTextStyle.copyWith(color: blueColor, fontSize: 32),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Ayo belajar bersama BILU !',
                  style: regularTextStyle.copyWith(
                      color: blackcolor, fontSize: 14),
                ),
                SizedBox(
                  height: 27,
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.green,
                  ),
                  alignment: Alignment.centerLeft,
                  height: 55,
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      'Tidak Ada Tagihan Yang Menunggak',
                      style: semiBoldTextStyle.copyWith(
                          color: whiteColor, fontSize: 16),
                    ),
                  ),
                ),
                SizedBox(
                  height: 27,
                ),
                GestureDetector(
                  onTap: () {
                    // Aksi ketika GestureDetector ditekan
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              VideoListScreen()), // Navigasi ke VideoListScreen
                    );
                  },
                  child: Image.asset(
                      'assets/images/Button Video Pembelajaran.png'),
                ),
                SizedBox(
                  height: 10,
                ),
                GestureDetector(
            onTap: () {
                    // Aksi ketika GestureDetector ditekan
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              AbsensiScreen()), // Navigasi ke VideoListScreen
                    );
                  },
                  child: Image.asset('assets/images/Button Absensi.png'),
                ),
                SizedBox(
                  height: 10,
                ),
                GestureDetector(
                  onTap: () {},
                  child: Image.asset('assets/images/Button Keuangan.png'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
