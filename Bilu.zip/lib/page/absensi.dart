import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

// Model Absensi
class Attendance {
  String date;
  bool isPresent;

  Attendance({required this.date, required this.isPresent});

  // Konversi dari Attendance ke JSON
  Map<String, dynamic> toJson() {
    return {
      'date': date,
      'isPresent': isPresent,
    };
  }

  // Konversi dari JSON ke Attendance
  factory Attendance.fromJson(Map<String, dynamic> json) {
    return Attendance(
      date: json['date'],
      isPresent: json['isPresent'],
    );
  }
}

// Fungsi untuk mendapatkan file JSON
Future<File> _getAttendanceFile() async {
  final directory = await getApplicationDocumentsDirectory();
  return File('${directory.path}/attendance.json');
}

// Fungsi untuk menyimpan absensi ke dalam file JSON
Future<void> saveAttendance(List<Attendance> attendanceList) async {
  final file = await _getAttendanceFile();
  String json = jsonEncode(attendanceList.map((att) => att.toJson()).toList());
  await file.writeAsString(json);
}

// Fungsi untuk memuat absensi dari file JSON
Future<List<Attendance>> loadAttendance() async {
  try {
    final file = await _getAttendanceFile();
    String content = await file.readAsString();
    List<dynamic> jsonList = jsonDecode(content);
    return jsonList.map((json) => Attendance.fromJson(json)).toList();
  } catch (e) {
    return [];
  }
}

// Halaman Absensi
class AbsensiScreen extends StatefulWidget {
  @override
  _AbsensiScreenState createState() => _AbsensiScreenState();
}

class _AbsensiScreenState extends State<AbsensiScreen> {
  List<Attendance> attendanceList = [];

  @override
  void initState() {
    super.initState();
    // Memuat absensi dari file JSON
    loadAttendance().then((data) {
      setState(() {
        attendanceList = data;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    DateTime now = DateTime.now();
    int daysInMonth = DateTime(now.year, now.month + 1, 0).day;

    return Scaffold(
      appBar: AppBar(title: Text('Absensi Bulanan')),
      body: GridView.builder(
        padding: EdgeInsets.all(8.0),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 7, // Tampilkan sebagai hari dalam seminggu
          crossAxisSpacing: 8.0,
          mainAxisSpacing: 8.0,
        ),
        itemCount: daysInMonth,
        itemBuilder: (context, index) {
          String day = (index + 1).toString().padLeft(2, '0');
          String date = '${now.year}-${now.month.toString().padLeft(2, '0')}-$day';

          bool isPresent = attendanceList.any((att) => att.date == date && att.isPresent);

          return GestureDetector(
            onTap: () {
              setState(() {
                bool currentStatus = attendanceList.any((att) => att.date == date && att.isPresent);
                if (currentStatus) {
                  attendanceList.removeWhere((att) => att.date == date);
                } else {
                  attendanceList.add(Attendance(date: date, isPresent: true));
                }
                saveAttendance(attendanceList);
              });
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.blue[100],
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: Text(
                  isPresent ? "$day ★" : "$day",
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

